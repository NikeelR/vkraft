import React from "react";
import { render } from "react-dom";


import App from "/src/App.jsx";

render(
    <App />, 
    document.getElementById("root")
)